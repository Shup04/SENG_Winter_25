Directories:

+ FreeRTOS-Plus\Demo\FreeRTOS_Plus_POSIX_with_actor_Windows_Simulator
  contains a FreeRTOS windows simulator demo project for FreeRTOS+POSIX.  
  See http://www.FreeRTOS.org/FreeRTOS-Plus/FreeRTOS_Plus_POSIX/ for information about this project.
  
